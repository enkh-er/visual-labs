package sample.model;
import javafx.beans.property.*;

public class StudentScore {
    private int studentID;
    private String firstName;
    private String lastName;
    private int Attendance20;
    private int AttendanceEG;
    private double AttendancePercent;
    private int WrittenQuiz50;
    private int WrittenQuizEG;
    private double WrittenQuizPercent;
    private int PraticalQuiz50;
    private int PraticalQuizEG;
    private double PraticalQuizPercent;
    private int Project100;
    private int ProjectEG;
    private double ProjectPercent;
    private int PrelimExam100;
    private int PrelimExamEG;
    private double PrelimExamPercent;
    private double PrelimGrade;
    private String Remark;

    public StudentScore() {
    }

    public StudentScore(int studentID, String firstName, String lastName, int attendance20, int attendanceEG, double attendancePercent, int writtenQuiz50, int writtenQuizEG, double writtenQuizPercent, int praticalQuiz50, int praticalQuizEG, double praticalQuizPercent, int project100, int projectEG, double projectPercent, int prelimExam100, int prelimExamEG, double prelimExamPercent, double prelimGrade, String remark) {
        this.studentID = studentID;
        this.firstName = firstName;
        this.lastName = lastName;
        Attendance20 = attendance20;
        AttendanceEG = attendanceEG;
        AttendancePercent = attendancePercent;
        WrittenQuiz50 = writtenQuiz50;
        WrittenQuizEG = writtenQuizEG;
        WrittenQuizPercent = writtenQuizPercent;
        PraticalQuiz50 = praticalQuiz50;
        PraticalQuizEG = praticalQuizEG;
        PraticalQuizPercent = praticalQuizPercent;
        Project100 = project100;
        ProjectEG = projectEG;
        ProjectPercent = projectPercent;
        PrelimExam100 = prelimExam100;
        PrelimExamEG = prelimExamEG;
        PrelimExamPercent = prelimExamPercent;
        PrelimGrade = prelimGrade;
        Remark = remark;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAttendance20() {
        return Attendance20;
    }

    public void setAttendance20(int attendance20) {
        Attendance20 = attendance20;
    }

    public int getAttendanceEG() {
        return AttendanceEG;
    }

    public void setAttendanceEG(int attendanceEG) {
        AttendanceEG = attendanceEG;
    }

    public double getAttendancePercent() {
        return AttendancePercent;
    }

    public void setAttendancePercent(double attendancePercent) {
        AttendancePercent = attendancePercent;
    }

    public int getWrittenQuiz50() {
        return WrittenQuiz50;
    }

    public void setWrittenQuiz50(int writtenQuiz50) {
        WrittenQuiz50 = writtenQuiz50;
    }

    public int getWrittenQuizEG() {
        return WrittenQuizEG;
    }

    public void setWrittenQuizEG(int writtenQuizEG) {
        WrittenQuizEG = writtenQuizEG;
    }

    public double getWrittenQuizPercent() {
        return WrittenQuizPercent;
    }

    public void setWrittenQuizPercent(double writtenQuizPercent) {
        WrittenQuizPercent = writtenQuizPercent;
    }

    public int getPraticalQuiz50() {
        return PraticalQuiz50;
    }

    public void setPraticalQuiz50(int praticalQuiz50) {
        PraticalQuiz50 = praticalQuiz50;
    }

    public int getPraticalQuizEG() {
        return PraticalQuizEG;
    }

    public void setPraticalQuizEG(int praticalQuizEG) {
        PraticalQuizEG = praticalQuizEG;
    }

    public double getPraticalQuizPercent() {
        return PraticalQuizPercent;
    }

    public void setPraticalQuizPercent(double praticalQuizPercent) {
        PraticalQuizPercent = praticalQuizPercent;
    }

    public int getProject100() {
        return Project100;
    }

    public void setProject100(int project100) {
        Project100 = project100;
    }

    public int getProjectEG() {
        return ProjectEG;
    }

    public void setProjectEG(int projectEG) {
        ProjectEG = projectEG;
    }

    public double getProjectPercent() {
        return ProjectPercent;
    }

    public void setProjectPercent(double projectPercent) {
        ProjectPercent = projectPercent;
    }

    public int getPrelimExam100() {
        return PrelimExam100;
    }

    public void setPrelimExam100(int prelimExam100) {
        PrelimExam100 = prelimExam100;
    }

    public int getPrelimExamEG() {
        return PrelimExamEG;
    }

    public void setPrelimExamEG(int prelimExamEG) {
        PrelimExamEG = prelimExamEG;
    }

    public double getPrelimExamPercent() {
        return PrelimExamPercent;
    }

    public void setPrelimExamPercent(double prelimExamPercent) {
        PrelimExamPercent = prelimExamPercent;
    }

    public double getPrelimGrade() {
        return PrelimGrade;
    }

    public void setPrelimGrade(double prelimGrade) {
        PrelimGrade = prelimGrade;
    }

    public String getRemark() {
        return Remark;
    }

    public void setRemark(String remark) {
        Remark = remark;
    }
}
