package sample.database;

import java.util.List;

public interface DAO<T>{
    //Ugugdsun id-aar ugugliin sangaas hailt hiineMySqlDaoFactory
    T findById(int id);

    //ugugdliin sangaas bvh elementiin utgiig butsaana
    List<T> findAll();

    //ugugliin sanruu ugugdul hadgalna
    boolean save(T t);

    //ugugliin sanruu ugugdul hadgalna
    boolean delete(int id);

    //ugugliin sanruu ugugdul hadgalna
    boolean update(T t);
}
