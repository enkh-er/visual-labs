package sample.database;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import sample.model.StudentScore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.List;

public class StudentRecordDAO implements DAO<StudentScore>{
    Connection conn=MySqlDaoFactory.createConnection();
    ResultSet rs=null;
    PreparedStatement ps=null;

    @Override
    public StudentScore findById(int id) {
        String sql="Select * from StudentScore where StudentId=?";
        StudentScore studentScore=null;
        try {
            ps=conn.prepareStatement(sql);
            ps.setInt(1,id);
            rs=ps.executeQuery();
            while(rs.next()) {
                studentScore=new StudentScore(rs.getInt("StudentId"),
                        rs.getString("firstName"),rs.getString("lastName"),
                        rs.getInt("Attendance20"),rs.getInt("AttendanceEG"),rs.getDouble("AttendancePercent"),
                        rs.getInt("WrittenQuiz50"),rs.getInt("WrittenQuizEG"),rs.getDouble("WrittenQuizPercent"),
                        rs.getInt("PraticalQuiz50"),rs.getInt("PraticalQuizEG"),rs.getDouble("PraticalQuizPercent"),
                        rs.getInt("Project100"),rs.getInt("ProjectEG"),rs.getDouble("ProjectPercent"),
                        rs.getInt("PrelimExam100"),rs.getInt("PrelimExamEG"),rs.getDouble("PrelimExamPercent"),
                        rs.getDouble("PrelimGrade"),rs.getString("Remark"));
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return studentScore;
    }

    @Override
    public List<StudentScore> findAll() {
        ObservableList<StudentScore> list= FXCollections.observableArrayList();
        try {
            ps=conn.prepareStatement("Select * from StudentScore");
            rs=ps.executeQuery();
            while(rs.next()) {
                list.add(new StudentScore(rs.getInt("StudentId"),
                        rs.getString("firstName"),rs.getString("lastName"),
                        rs.getInt("Attendance20"),rs.getInt("AttendanceEG"),rs.getDouble("AttendancePercent"),
                        rs.getInt("WrittenQuiz50"),rs.getInt("WrittenQuizEG"),rs.getDouble("WrittenQuizPercent"),
                        rs.getInt("PraticalQuiz50"),rs.getInt("PraticalQuizEG"),rs.getDouble("PraticalQuizPercent"),
                        rs.getInt("Project100"),rs.getInt("ProjectEG"),rs.getDouble("ProjectPercent"),
                        rs.getInt("PrelimExam100"),rs.getInt("PrelimExamEG"),rs.getDouble("PrelimExamPercent"),
                        rs.getDouble("PrelimGrade"),rs.getString("Remark")));
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean save(StudentScore studentScore) {
        String sql ="insert into StudentScore (StudentId,firstName,lastName,Attendance20,AttendanceEG,AttendancePercent," +
                "WrittenQuiz50,WrittenQuizEG,WrittenQuizPercent,PraticalQuiz50,PraticalQuizEG,PraticalQuizPercent," +
                "Project100,ProjectEG,ProjectPercent,PrelimExam100,PrelimExamEG,PrelimExamPercent,PrelimGrade,Remark) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            ps=conn.prepareStatement(sql);
            ps.setInt(1, studentScore.getStudentID());
            ps.setString(2, studentScore.getFirstName());
            ps.setString(3, studentScore.getLastName());
            ps.setInt(4, studentScore.getAttendance20());
            ps.setInt(5, studentScore.getAttendanceEG());
            ps.setDouble(6, studentScore.getAttendancePercent());
            ps.setDouble(7, studentScore.getWrittenQuiz50());
            ps.setInt(8, studentScore.getWrittenQuizEG());
            ps.setDouble(9, studentScore.getWrittenQuizPercent());
            ps.setInt(10, studentScore.getPraticalQuiz50());
            ps.setInt(11, studentScore.getPraticalQuizEG());
            ps.setDouble(12, studentScore.getPraticalQuizPercent());
            ps.setDouble(13, studentScore.getProject100());
            ps.setDouble(14, studentScore.getProjectEG());
            ps.setDouble(15, studentScore.getProjectPercent());
            ps.setInt(16, studentScore.getPrelimExam100());
            ps.setInt(17, studentScore.getPrelimExamEG());
            ps.setDouble(18, studentScore.getPrelimExamPercent());
            ps.setDouble(19, studentScore.getPrelimGrade());
            ps.setString(20, studentScore.getRemark());
            ps.execute();
            return true;
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "delete from StudentScore where StudentId = ?";
        try {
            ps=conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
            return true;
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public boolean update(StudentScore studentScore) {
        return false;
    }
}
