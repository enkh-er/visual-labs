package sample.view;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import sample.database.StudentRecordDAO;
import sample.model.StudentScore;

import javax.swing.*;

public class StudentRecordController {


    @FXML
    private TextField txtStudentId;

    @FXML
    private TextField txtFirstName;

    @FXML
    private TextField txtLastName;

    @FXML
    private TextField txtAttendanceScore;

    @FXML
    private TextField txtAttendanceEG;

    @FXML
    private TextField txtAttendanceTen;

    @FXML
    private TextField txtProjectScore;

    @FXML
    private TextField txtProjectEG;

    @FXML
    private TextField txtProjectTen;

    @FXML
    private TextField txtWrittenScore;

    @FXML
    private TextField txtWrittenEG;

    @FXML
    private TextField txtWrittenTen;

    @FXML
    private TextField txtPrelimScore;

    @FXML
    private TextField txtPrelimEG;

    @FXML
    private TextField txtPrelimTen;

    @FXML
    private TextField txtPracticalScore;

    @FXML
    private TextField txtPracticalEG;

    @FXML
    private TextField txtPracticalTen;

    @FXML
    private TextField txtPrelimGrade;

    @FXML
    private TextField txtRemark;

    StudentRecordDAO dao=new StudentRecordDAO();


    @FXML
    private TableView<StudentScore> table;

    ObservableList<StudentScore> studentScores= FXCollections.observableArrayList();

    TableColumn colStudentID = new TableColumn("StudentID");
    TableColumn colFirstName = new TableColumn("FirstName");
    TableColumn colLastName = new TableColumn("LastName");
    TableColumn colScore1 = new TableColumn("20");
    TableColumn colScoreEG1 = new TableColumn("EG");
    TableColumn colScoreTen1 = new TableColumn("1st-10%");
    TableColumn colScore2 = new TableColumn("50");
    TableColumn colScoreEG2 = new TableColumn("EG");
    TableColumn colScoreTen2 = new TableColumn("2nd-10%");
    TableColumn colScore3 = new TableColumn("50");
    TableColumn colScoreEG3 = new TableColumn("EG");
    TableColumn colScoreTen3 = new TableColumn("3rd-20%");
    TableColumn colScore4 = new TableColumn("100");
    TableColumn colScoreEG4 = new TableColumn("EG");
    TableColumn colScoreTen4 = new TableColumn("4th-30%");
    TableColumn colScore5 = new TableColumn("100");
    TableColumn colScoreEG5 = new TableColumn("EG");
    TableColumn colScoreTen5 = new TableColumn("5th-30%");
    TableColumn colPremlimGrade = new TableColumn("EG");
    TableColumn colremark = new TableColumn("5th-30%");

    private void createTableColumns(){
        table.getColumns().addAll(colStudentID, colFirstName,colLastName,
                colScore1,colScoreEG1,colScoreTen1,colScore2,colScoreEG2,colScoreTen2,colScore3,colScoreEG3
        ,colScoreTen3,colScore4,colScoreEG4,colScoreTen4,colScore5,colScoreEG5,colScoreTen5,colPremlimGrade,colremark);
    }

    public void updateTableData() {
        colStudentID.setCellValueFactory(new PropertyValueFactory<StudentScore, Integer>("studentID"));
        colFirstName.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("firstName"));
        colLastName.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("lastName"));
        colScore1.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("Attendance20"));
        colScoreEG1.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("AttendanceEG"));
        colScoreTen1.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("AttendancePercent"));
        colScore2.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("WrittenQuiz50"));
        colScoreEG2.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("WrittenQuizEG"));
        colScoreTen2.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("WrittenQuizPercent"));
        colScore3.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("PraticalQuiz50"));
        colScoreEG3.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("PraticalQuizEG"));
        colScoreTen3.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("PraticalQuizPercent"));
        colScore4.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("Project100"));
        colScoreEG4.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("ProjectEG"));
        colScoreTen4.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("ProjectPercent"));
        colScore5.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("PrelimExam100"));
        colScoreEG5.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("PrelimExamEG"));
        colScoreTen5.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("PrelimExamPercent"));

        colPremlimGrade.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("PrelimGrade"));
        colremark.setCellValueFactory(new PropertyValueFactory<StudentScore,String>("Remark"));
        studentScores.addAll(dao.findAll());
        table.setItems(studentScores);
    }

    public void calculateScore(){
        txtAttendanceScore.textProperty().addListener(
                (arg,oldVal,newVal)->{
                    if(newVal != null && !txtAttendanceScore.getText().trim().isEmpty()){
                        try {
                            int score=Integer.parseInt(txtAttendanceScore.getText());
                            int eg=score*100/20;
                            double percent=(double)score*10/20;
                            txtAttendanceEG.setText(String.valueOf(eg));
                            txtAttendanceTen.setText(String.valueOf(percent));
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
        );
        txtWrittenScore.textProperty().addListener(
                (arg,oldVal,newVal)->{
                    if(newVal != null && !txtWrittenScore.getText().trim().isEmpty()){
                        try {
                            int score=Integer.parseInt(txtWrittenScore.getText());
                            int eg=score*100/50;
                            double percent=(double)score*10/50;
                            txtWrittenEG.setText(String.valueOf(eg));
                            txtWrittenTen.setText(String.valueOf(percent));
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
        );
        txtPracticalScore.textProperty().addListener(
                (arg,oldVal,newVal)->{
                    if(newVal != null && !txtPracticalScore.getText().trim().isEmpty()){
                        try {
                            int score=Integer.parseInt(txtPracticalScore.getText());
                            int eg=score*100/50;
                            double percent=(double)score*20/50;
                            txtPracticalEG.setText(String.valueOf(eg));
                            txtPracticalTen.setText(String.valueOf(percent));
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
        );
        txtProjectScore.textProperty().addListener(
                (arg,oldVal,newVal)->{
                    if(newVal != null && !txtProjectScore.getText().trim().isEmpty()){
                        try {
                            int score=Integer.parseInt(txtProjectScore.getText());
                            double percent=(double)score*30/100;
                            txtProjectEG.setText(String.valueOf(score));
                            txtProjectTen.setText(String.valueOf(percent));
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
        );
        txtPrelimScore.textProperty().addListener(
                (arg,oldVal,newVal)->{
                    if(newVal != null && !txtPrelimScore.getText().trim().isEmpty()){
                        try {
                            int score=Integer.parseInt(txtPrelimScore.getText());
                            double percent=(double)score*30/100;
                            txtPrelimEG.setText(String.valueOf(score));
                            txtPrelimTen.setText(String.valueOf(percent));
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
        );
    }

    public void computeGrades(){
        if(scoreEmpty()){
            double totalScore;
            try {
                double score1=Double.parseDouble(txtAttendanceTen.getText());
                double score2=Double.parseDouble(txtWrittenTen.getText());
                double score3=Double.parseDouble(txtPrelimTen.getText());
                double score4=Double.parseDouble(txtPracticalTen.getText());
                double score5=Double.parseDouble(txtProjectTen.getText());
                totalScore =score1+score2+score3+score4+score5;
                txtPrelimGrade.setText(String.valueOf(totalScore));
                if(totalScore>=90){
                    txtRemark.setText("Passed");
                }
                else{
                    txtRemark.setText("Failed");
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "Onoog bvren gvitset oruulna uu!");
        }

    }

    private boolean scoreEmpty(){
        if(txtAttendanceTen.getText() == null || txtAttendanceTen.getText().trim().isEmpty()){
            return false;
        }
        if(txtWrittenTen.getText() == null || txtWrittenTen.getText().trim().isEmpty()){
            return false;
        }
        if(txtPracticalTen.getText() == null || txtPracticalTen.getText().trim().isEmpty()){
            return false;
        }
        if(txtProjectTen.getText() == null || txtProjectTen.getText().trim().isEmpty()){
            return false;
        }
        if(txtPrelimTen.getText() == null || txtPrelimTen.getText().trim().isEmpty()){
            return false;
        }
        return true;
    }

    public void saveStudentRecord(){
        try {
            StudentScore studentScore=new StudentScore(Integer.parseInt(txtStudentId.getText()),txtFirstName.getText(),txtLastName.getText(),
                    Integer.parseInt(txtAttendanceScore.getText()),Integer.parseInt(txtAttendanceEG.getText()),Double.parseDouble(txtAttendanceTen.getText()),
                    Integer.parseInt(txtWrittenScore.getText()),Integer.parseInt(txtWrittenEG.getText()),Double.parseDouble(txtWrittenTen.getText()),
                    Integer.parseInt(txtPracticalScore.getText()),Integer.parseInt(txtPracticalEG.getText()),Double.parseDouble(txtPracticalTen.getText()),
                    Integer.parseInt(txtProjectScore.getText()),Integer.parseInt(txtProjectEG.getText()),Double.parseDouble(txtProjectTen.getText()),
                    Integer.parseInt(txtPrelimScore.getText()),Integer.parseInt(txtPrelimEG.getText()),Double.parseDouble(txtPrelimTen.getText()),
                    Double.parseDouble(txtPrelimGrade.getText()),txtRemark.getText());
            if(dao.save(studentScore)){
                JOptionPane.showMessageDialog(null, "Amjilttai orloo!");
                studentScores.add(studentScore);
            }else{
                JOptionPane.showMessageDialog(null, "ogogdol oruulahad garlaa!");
            }

        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Aldaa garlaa!");
        }
    }

    public void clearAllField(){
        txtStudentId.setText(null);
        txtFirstName.setText(null);
        txtLastName.setText(null);
        txtAttendanceTen.setText(null);
        txtAttendanceScore.setText(null);
        txtAttendanceEG.setText(null);
        txtWrittenTen.setText(null);
        txtWrittenEG.setText(null);
        txtWrittenScore.setText(null);
        txtPrelimTen.setText(null);
        txtPrelimEG.setText(null);
        txtPrelimScore.setText(null);
        txtPrelimGrade.setText(null);
        txtProjectTen.setText(null);
        txtProjectEG.setText(null);
        txtProjectScore.setText(null);
        txtPracticalTen.setText(null);
        txtPracticalEG.setText(null);
        txtPracticalScore.setText(null);
        txtRemark.setText(null);
    }
    public void ShowDetails(){
        int id=Integer.parseInt(txtStudentId.getText());
        StudentScore studentScore =dao.findById(id);
        txtStudentId.setText(String.valueOf(studentScore.getStudentID()));
        txtFirstName.setText(studentScore.getFirstName());
        txtLastName.setText(studentScore.getLastName());
        txtAttendanceTen.setText(String.valueOf(studentScore.getAttendancePercent()));
        txtAttendanceScore.setText(String.valueOf(studentScore.getAttendance20()));
        txtAttendanceEG.setText(String.valueOf(studentScore.getAttendanceEG()));
        txtWrittenTen.setText(String.valueOf(studentScore.getWrittenQuizPercent()));
        txtWrittenEG.setText(String.valueOf(studentScore.getWrittenQuizEG()));
        txtWrittenScore.setText(String.valueOf(studentScore.getWrittenQuiz50()));
    }
    public void delete(){
        int id=Integer.parseInt(txtStudentId.getText());
        if(dao.delete(id)){
            JOptionPane.showMessageDialog(null, "ogogdol ustgalaa!");
            updateTableData();
        }
        else {
            JOptionPane.showMessageDialog(null, "aldaa garlaa!");
        }
    }
    public void update(){
        int id=Integer.parseInt(txtStudentId.getText());
        StudentScore studentScore =dao.findById(id);
    }
    @FXML
    void closeProgram(ActionEvent event) {
        Platform.exit();
    }
    @FXML
    void initialize() {
        createTableColumns();
        calculateScore();
        updateTableData();
    }
}
